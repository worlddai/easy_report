﻿ //--获取字符串实际长度
 var GetLength = function(str) {
 	var realLength = 0,
 		len = str.length,
 		charCode = -1;
 	for (var i = 0; i < len; i++) {
 		charCode = str.charCodeAt(i);
 		if (charCode >= 0 && charCode <= 128) realLength += 1;
 		else realLength += 2;
 	}
 	return realLength;
 };

 //--截取
 function cutstr(str, len) {
 	var str_length = 0;
 	var str_len = 0;
 	str_cut = new String();
 	str_len = str.length;
 	for (var i = 0; i < str_len; i++) {
 		a = str.charAt(i);
 		str_length++;
 		if (escape(a).length > 4) {
 			//中文字符的长度经编码之后大于4  
 			str_length++;
 		}
 		str_cut = str_cut.concat(a);
 		if (str_length >= len) {
 			return str_cut;
 		}
 	}
 	if (str_length < len) {
 		return str;
 	}
 }

 //--截取总字符串
function cutString(pes, str, nMode) {

	var totalWord = GetLength(str);

	var nLinedRemain = Math.floor(totalWord * pes / Dta.linesize) - 1;

	var sublen = nLinedRemain * Dta.linesize;

	var first_cut_str = cutstr(str, sublen);

	var first_remained_str =splitstring(str,first_cut_str);

	var second_cut_str = getbalanceStr(first_cut_str, first_remained_str, nMode);

	return {
		subed: second_cut_str,
		remained: splitstring(str,second_cut_str)
	}
}

function splitstring(stringtotal,splitor)
{
	var index = stringtotal.indexOf(splitor);
	
	if(index==0)
	{
		var splits = stringtotal.split(splitor);

		if(splits.length>2)
		{
			var rets = "";
			for(var i = 1;i<splits.length;i++)
			{
				if(i!=splits.length-1)
					rets+=(splits[i]+splitor)
				else
					rets+=splits[i];
			}
			return rets;
		}else
			return splits[1];
	}
	return stringtotal;
}

//--补充字符串直到填充满一行
function getbalanceStr(part1, part2, nMode) {
	var $container;
	if(nMode == 0)
	{
		$container =$('#test-font');
	}
	else if(nMode == -1)
	{
		$container =$('#test-font-indent');
	}
	else if(nMode == 1)
	{
		$container =$('#test-font-padding');
	}
	$container.get(0).innerHTML = part1;
	var orgHeight = $container.height();
	var testPart = part1;
	var totolOffset = 0;
	for (var i = 0; i < part2.length; i++) {
		testPart = testPart + part2.charAt(i);
		$container.get(0).innerHTML = testPart;
		if (orgHeight != $container.height()) {
			totolOffset = i;
			break;
		}
	}
	return testPart.substr(0, testPart.length - 1)
}