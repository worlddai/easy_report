window.onload = function() {
	//--初始化相关参数及函数
	init();

	//--预处理图片相关数据
	$('.loading1').shCircleLoader();
	// reqData(function(data_step1){
		let data_step1 = JSON.parse(`[{"type":"title","value":"一、产品描述"},{"paddingfont":true,"type":"font","value":"本产品是以经国家动物卫生监督机构（包含进出境检验检疫机构）检验、检疫合格的生牛的鲜、冻骨为原料，经提取分离得到的具有牛骨油特有香味的油脂，所用原料不得添加脂肪组织。"},{"type":"title","value":"二、通则要求"},{"paddingfont":true,"type":"font","value":"1.此原料应符合《食品安全标准》之规定。<br>2.此原料的来源（食品/食品添加剂/食品相关产品）应当按其相关之《食品安全标准》进行检验。<br>3.此原料的生产、流通活动应依法取得食品生产许可和食品流通许可。<br>4.此原料的生产经营应符合良好生产规范要求（GMP），并实施危害分析与关键控制点体系（HACCP）。<br>5.此原料应建立产品的追溯系统，在发现生产产品不符合食品安全标准，应当立即停止生产，召回相关产品，并通知生产经营者。<br>6.此原料的检验可以自行对所生产食品进行检验，也可以委托符合《食安法》规定的食品检验机构进行检验。委托检验机构应为按照国家有关认证认可规定取得资质认定的单位。<br>7.此原料（食品/食品添加剂/食品相关产品）的相关标准发生改变，供应商必须及时提供书面说明和建议可替换品。产品中添加、去除某种食品/食品添加剂/食品相关产品或其添加量发生变化，需得到本公司的书面同意，此规定也适用于加工方法、加工助剂等发生改变。<br>8.“纯”及“纯度”：指原料本身100%即纯。例如：辣椒不可掺青椒或类似的原料、辣椒梗等。<br>9.等级：指原料依国标或行情分A、B、C级的指标（例如：花皮比例）。<br>10.“复配”：需依研发配方比例真实执行。"},{"type":"title","value":"三、感官要求"},{"type":"table","value":{"ratio":["0.25","0.25","0.25","0.25"],"rows":[["色泽","凝固态时呈淡黄色；融化态时呈黄色、透明","目视","1.依标样；<br>2.GB 10146（仅供送外检使用）"],["滋味","具有正常牛骨油滋味","品尝","1.依标样；<br>2.GB 10146（仅供送外检使用）"],["气味","具有正常牛骨油香味，无腐臭及其他异味","鼻嗅","1.依标样；<br>2.GB 10146（仅供送外检使用）"],["状态","凝固时为细腻软膏状；融化态时为液态；无肉眼可见外来杂质，不允许有沉淀物","目视","1.依标样；<br>2.GB 10146（仅供送外检使用）"]],"title":["项目","感官要求","检验方法","备注"]}},{"type":"title","value":"四、理化指标"},{"type":"table","value":{"ratio":["0.25","0.25","0.25","0.25"],"rows":[["水分及挥发物","≤ 0.5%","W-0510-4SF1c","GB 5009.236（仅供送外检使用）"],["酸价","≤ 2.5(KOH) mg/g","W-0510-4YSJ1c","GB 5009.229（仅供送外检使用）"],["过氧化值","≤ 5.0Meq/Kg","W-0510-4GYH1c","GB 5009.227（仅供送外检使用）"],["反式脂肪酸","≤ 8.0%","GB 5009.257",""],["丙二醛/(mg/100g)","≤ 0.25mg/100g","GB 5009.181",""],["游离棉酚","不得检出","GB 5009.148","检出限：按GB 5009.148所选用检测方法的检出限执行"]],"title":["项目","指标","检验方法","备注"]}},{"type":"title","value":"五、安全卫生指标"},{"margins":5,"type":"font","value":"1. 兽药残留"},{"type":"table","value":{"ratio":["0.25","0.25","0.25","0.25"],"rows":[["磺胺类","≤ 0.1mg/kg ","GB/T 20759<br>农业部1025号公告-23-2008<br>GB 29694",""],["己烯雌酚(Diethylstilbestrol)","不得检出","GB/T 21981","检出限：依所选检测方法的检出限执行"],["克伦特罗(Clenbuterol)","不得检出","GB/T 22286","检出限：依所选检测方法的检出限执行"],["莱克多巴胺(Ractopamine)","不得检出","GB/T 22286","检出限：依所选检测方法的检出限执行"],["链霉素","≤ 0.5mg/kg ","GB/T 21323",""],["氯丙那林(Clorprenaline)","不得检出","农业部1025号公告-18-2008","检出限：依所选检测方法的检出限执行"],["氯霉素(Chloramphenicol)","不得检出","GB/T 20756<br>GB/T 22338<br>SN/T 1864","检出限：依所选检测方法的检出限执行"],["马布特罗(Mabuterol)","不得检出","GB/T 22286","检出限：依所选检测方法的检出限执行"],["庆大霉素","≤ 0.1mg/kg ","GB/T 21323",""],["沙丁胺醇(Salbutamol)","不得检出","GB/T 22286","检出限：依所选检测方法的检出限执行"],["特布他林(Terbutaline)","不得检出","GB/T 22286","检出限：依所选检测方法的检出限执行"],["土霉素","不得检出","GB/T 21317<br>GB/T 5009.116",""],["西马特罗(Cimaterol)","不得检出","GB/T 22286","检出限：依所选检测方法的检出限执行"],["溴布特罗(Brombuterol)","不得检出","GB/T 22286","检出限：依所选检测方法的检出限执行"],["说明","其它不得添加项依备注要求","",""]],"title":["项目","指标","检验方法","备注"]}},{"margins":5,"type":"font","value":"2. 农药残留"},{"type":"table","value":{"ratio":["0.25","0.25","0.25","0.25"],"rows":[["2,4-滴和2,4-滴钠盐（2,4-D和2,4-D Na）","≤ 0.2mg/kg","NY/T 1434",""],["2甲4氯（钠）[MCPA（sodium）]","≤ 0.1mg/kg","GB 23200.104","以2甲4氯计"],["百菌清（chlorothalonil）","≤ 0.02mg/kg","SN/T 2320",""],["苯醚甲环唑（difenoconazole）","≤ 0.2mg/kg","GB/T 19650<br>GB 23200.49<br>GB 23200.113","以脂肪中的残留量计"],["苯线磷（fenamiphos）","≤ 0.01mg/kg","GB/T 20770<br>GB/T 19650",""],["吡丙醚（pyriproxyfen）","≤ 0.01mg/kg","GB 23200.113<br>GB 23200.64","以脂肪中的残留量计"],["吡虫啉（imidacloprid）","≤ 0.1mg/kg ","GB/T 20770<br>GB/T 20769<br>GB/T 20772",""],["吡唑醚菌酯（pyraclostrobin）","≤ 0.5mg/kg","GB 23200.113<br>GB/T 19650","以脂肪中的残留量计"],["丙环唑（propiconazol）","≤ 0.01mg/kg","GB/T20772","以脂肪中的残留量计"],["丙溴磷（profenofos）","≤ 0.05mg/kg","SN/T 2234","以脂肪中的残留量计"],["虫酰肼（tebufenozide）","≤ 0.05mg/kg","GB/T 23211","以脂肪中的残留量计"],["除虫脲（diflubenzuron）","≤ 0.1mg/kg","GB 23200.45","以脂肪中的残留量计"],["敌草快（diquat）","≤ 0.05mg/kg","SN/T 0293",""],["敌敌畏（dichlorvos）","≤ 0.01mg/kg ","GB/T 5009.20<br>GB 23200.113",""],["丁苯吗啉（fenpropimorph）","≤ 0.02mg/kg","GB/T 23210",""],["丁硫克百威（carbosulfan）","≤ 0.05mg/kg","GB 23200.13<br>GB/T19650<br>GB 23200.33","以脂肪中的残留量计"],["啶虫脒（acetamiprid）","≤ 0.5mg/kg ","GB/T 20770<br>GB/T 20772",""],["啶酰菌胺（boscalid）","≤ 0.7mg/kg","GB/T 22979<br>GB/T 20769<br>GB/T 20770","以脂肪中的残留量计"],["毒死蜱（chlorpyrifos）","≤ 1mg/kg ","GB 23200.113<br>GB/T 20772","以脂肪中的残留量计"],["多菌灵（carbendazim）","≤ 0.05mg/kg ","GB/T 20772<br>NY/T 1680",""],["多杀霉素（spinosad）","≤ 3mg/kg","NY/T 1379","以脂肪中的残留量计"],["二苯胺（diphenylamine）","≤ 0.01mg/kg","GB/T 19650",""],["氟苯虫酰胺（flubendiamide）","≤ 2mg/kg","GB23200.76","以脂肪中的残留量计"],["氟硅唑（flusilazole）","≤ 1mg/kg","GB/T 20772<br>GB/T 20770<br>GB 23200.9","以脂肪中的残留量计"],["氟氯氰菊酯和高效氟氯氰菊酯（cyfluthrin和 beta-cyfluthrin）","≤ 0.2mg/kg","GB 23200.113","以脂肪中的残留量计"],["氟酰脲（novaluron）","≤ 10mg/kg","SN/T 2540<br>GB 23200.34","以脂肪中的残留量计"],["甲胺磷（methamidophos）","≤ 0.01mg/kg ","GB/T 20772<br>GB 23200.113<br>GB/T 5009.103",""],["甲拌磷（phorate）","≤ 0.02mg/kg","GB/T 23210<br>GB 23200.113",""],["甲基毒死蜱（chlorpyrifos-methyl）","≤ 0.1mg/kg","GB/T 20772<br>GB 23200.113","以脂肪中的残留量计"],["甲萘威（carbaryl）","≤ 0.05mg/kg","GB 23200.112<br>GB/T 5009.21<br>GB/T 20772",""],["喹氧灵（quinoxyfen）","≤ 0.2mg/kg","GB23200.56","以脂肪中的残留量计"],["乐果（dimethoate）","≤ 0.05mg/kg","GB 23200.113<br>GB/T 20772<br>GB/T 5009.20",""],["联苯菊酯（bifenthrin）","≤ 3mg/kg","SN/T 1969<br>GB 23200.113","以脂肪中的残留量计"],["联苯三唑醇（bitertanol）","≤ 0.05mg/kg","GB/T 20770<br>GB/T 20772<br>GB 23200.9","以脂肪中的残留量计"],["硫丹（endosulfan）","≤ 0.2mg/kg","GB/T 5009.162<br>GB/T 5009.19","以脂肪中的残留量计"],["螺螨酯（spirodiclofen）","≤ 0.01mg/kg","GB/T 20772<br>GB 23200.9","以脂肪中的残留量计"],["氯苯胺灵（chlorpropham）","≤ 0.1mg/kg","GB/T 19650",""],["氯苯嘧啶醇（fenarimol）","≤ 0.02mg/kg","GB/T 20772",""],["氯氟氰菊酯和高效氯氟氰菊酯（cyhalothrin和 lambda-cyhalothrin）","≤ 0.05mg/kg","GB/T 23210<br>GB 23200.113","以脂肪中的残留量计"],["氯菊酯（permethrin）","≤ 1mg/kg","GB/T 5009.162<br>GB 23200.113","以脂肪中的残留量计"],["氯氰菊酯和高效氯氰菊酯（cypermethrin和beta-cypermethrin）","≤ 2mg/kg ","GB 23200.113<br>GB/T 5009.162","以脂肪中的残留量计"],["麦草畏（dicamba）","≤ 0.03mg/kg","SN/T 1606",""],["灭线磷（ethoprophos）","≤ 0.01mg/kg","GB/T 20772<br>GB 23200.113<br>SN/T 3768",""],["氰戊菊酯和S-氰戊菊酯（fenvalerate和esfenvalerate）","≤ 1mg/kg ","GB 23200.113<br>GB/T 5009.162","以脂肪中的残留量计"],["炔螨特（propargite）","≤ 0.1mg/kg","GB/T 23211<br>GB 23200.9<br>NY/T 1652","以脂肪中的残留量计"],["噻虫啉（thiacloprid）","≤ 0.1mg/kg","GB/T 20770",""],["噻虫嗪（thiamethoxam）","≤ 0.02mg/kg","GB 23200.39",""],["噻节因（dimethipin）","≤ 0.01mg/kg","GB/T 20771<br>GB/T 23210",""],["噻菌灵（thiabendazole）","≤ 0.1mg/kg","GB/T 20772",""],["噻螨酮（hexythiazox）","≤ 0.05mg/kg ","GB/T 20770","以脂肪中的残留量计"],["噻嗪酮（buprofezin）","≤ 0.05mg/kg ","GB/T 20772",""],["杀螟硫磷（fenitrothion）","≤ 0.05mg/kg","GB/T 5009.161<br>GB 23200.113",""],["杀扑磷（methidathion）","≤ 0.02mg/kg","GB/T 20772",""],["霜霉威和霜霉威盐酸盐（propamocarb和propamocarb hydrochloride）","≤ 0.01mg/kg","GB/T 20772",""],["涕灭威（aldicarb）","≤ 0.01mg/kg ","GB 23200.112<br>GB/T 14929.2<br>SN/T 2560",""],["艾氏剂（aldrin）","≤ 0.2mg/kg","GB/T 5009.19<br>GB/T 5009.162","以脂肪计"],["滴滴涕（DDT）","≤ 0.2mg/kg ","GB/T 5009.162<br>GB/T 5009.19",""],["狄氏剂（dieldrin）","≤ 0.2mg/kg","GB/T 5009.19<br>GB/T 5009.162","以脂肪计"],["林丹（lindane）","≤ 0.1mg/kg ","GB/T 5009.19<br>GB/T 5009.162",""],["氯丹（chlordane）","≤ 0.05mg/kg","GB/T 5009.19<br>GB/T 5009.162","以脂肪计"],["七氯（heptachlor）","≤ 0.2mg/kg","GB/T 5009.162<br>GB/T 5009.19",""],["异狄氏剂（endrin）","≤ 0.1mg/kg","GB/T 5009.19<br>GB/T 5009.162","以脂肪计"],["呋虫胺（dinotefuran）","≤ 0.1mg/kg","GB/T 20770<br>GB 23200.37",""],["噻草酮（cycloxydim）","≤ 0.06mg/kg","GB 23200.3<br>GB/T 23211",""],["六六六（HCH)","≤ 0.1mg/kg","GB/T 5009.19<br>GB/T 5009.162",""],["噻虫胺","≤ 0.02mg/kg","GB 23200.39",""],["说明","百草枯≤0.005mg/kg；苯并烯氟菌唑≤0.03mg/kg；苯菌酮≤0.01mg/kg；苯嘧磺草胺≤0.01mg/kg；吡噻菌胺≤0.05mg/kg；吡唑萘菌胺≤0.01mg/kg；丙硫菌唑≤0.01mg/kg；草铵膦≤0.05mg/kg；噁唑菌酮≤0.5mg/kg；二嗪磷≤2mg/kg；氟吡菌胺≤0.01mg/kg；氟啶虫胺腈≤0.3mg/kg；甲氨基阿维菌素苯甲酸盐≤0.004mg/kg；甲基嘧啶磷≤0.01mg/kg；克百威≤0.05mg/kg；联苯肼酯≤0.05mg/kg；螺虫乙酯≤0.05mg/kg；氯氨吡啶酸≤0.1mg/kg；氯丙嘧啶酸≤0.01mg/kg；氯虫苯甲酰胺≤0.2mg/kg；咪鲜胺和咪鲜胺锰盐≤0.5mg/kg；咪唑菌酮≤0.01mg/kg；咪唑烟酸≤0.05mg/kg；醚菊酯≤0.5mg/kg；醚菌酯≤0.05mg/kg；嘧菌环胺≤0.01mg/kg；嘧菌酯≤0.05mg/kg；嘧霉胺≤0.05mg/kg；灭多威≤0.02mg/kg；灭蝇胺≤0.3mg/kg；嗪氨灵≤0.01mg/kg；氰氟虫腙≤0.02mg/kg；三唑醇≤0.02mg/kg；三唑酮≤0.02mg/kg；杀线威≤0.02mg/kg；双甲脒≤0.05mg/kg；四螨嗪≤0.05mg/kg；特丁硫磷≤0.05mg/kg；矮壮素≤0.2mg/kg；苯丁锡≤0.05mg/kg也需符合GB2763的相关规定。","",""]],"title":["项目","指标","检验方法","备注"]}},{"margins":5,"type":"font","value":"3. 污染物（除金属外）"},{"type":"table","value":{"ratio":["0.25","0.25","0.25","0.25"],"rows":[["苯并[a]芘","≤ 10μg/kg","GB 5009.27",""],["总砷（以As计）","≤ 0.1mg/kg","GB 5009.11",""]],"title":["项目","指标","检验方法","备注"]}},{"margins":5,"type":"font","value":"4. 真菌毒素"},{"type":"table","value":{"ratio":["0.25","0.25","0.25","0.25"],"rows":[["玉米赤霉烯酮","不得检出","GB 5009.209","检出限：所选检测方法的检出限执行"]],"title":["项目","指标","检验方法","备注"]}},{"margins":5,"type":"font","value":"5. 金属元素（重金属）"},{"type":"table","value":{"ratio":["0.25","0.25","0.25","0.25"],"rows":[["铅 (Pb)","≤ 0.1mg/kg","GB 5009.12",""]],"title":["项目","指标","检验方法","备注"]}},{"margins":5,"type":"font","value":"6. 非食品添加剂"},{"type":"table","value":{"ratio":["0.25","0.25","0.25","0.25"],"rows":[["邻苯二甲酸二（2-乙基）己酯（DEHP）","≤ 1.5mg/kg","GB 5009.271",""],["邻苯二甲酸二异壬酯（DINP）","≤ 9.0mg/kg","GB 5009.271",""],["邻苯二甲酸二正丁酯（DBP）","≤ 0.3mg/kg","GB 5009.271",""]],"title":["项目","指标","检验方法","备注"]}},{"margins":5,"type":"font","value":"7. 食品添加剂"},{"type":"table","value":{"ratio":["0.25","0.25","0.25","0.25"],"rows":[["没食子酸丙酯（PG）","不得检出","GB 5009.32","GB 5009.32<br>检出限按所选检验方法的检出限执行"],["叔丁基对苯二酚（TBHQ）","不得检出","GB 5009.32","GB 5009.32<br>检出限按所选检验方法的检出限执行"],["叔丁基对羟基茴香醚（BHA）","不得检出","GB 5009.32","GB 5009.32<br>检出限按所选检验方法的检出限执行"],["2,6-二叔丁基对甲基苯酚（BHT）","不得检出","GB 5009.32","GB 5009.32<br>检出限按所选检验方法的检出限执行"]],"title":["项目","指标","检验方法","备注"]}},{"type":"title","value":"六、包装说明"},{"margins":5,"paddingfont":true,"type":"font","value":"1.包装容器必须专用、清洁、干燥和密封，符合国家的相关规定和要求，塑化剂指标应符合国家相关法规要求。<br>2.包装标签上应注明品名、品号、配料、规格、生产日期、净含量、保质期、产品标准代号、贮存条件、生产许可证号、使用范围/使用量/使用方法（食品添加剂填写）、厂商名称、地址、电话、产地信息，且与康师傅研发共识标签模板，更改任何内容及格式都必须经过康师傅研发允许。<br>3.包装要求：<br>①4月-10月：非冷藏运输时，使用内附食品级塑料袋之铁桶包装，桶容：19公斤。<br>冷藏运输时，可使用内附食品级塑料袋之纸箱包装，箱容：20公斤。<br>②其他月份：使用内附食品级塑料袋之纸箱包装，箱容：20公斤。"},{"type":"title","value":"七、储运和保质期"},{"margins":5,"paddingfont":true,"type":"font","value":"运输中要注意安全，防止渗漏、污染和标签脱落，不得与有毒有害物品混装运输"},{"type":"table","value":{"ratio":[0.16,0.2,0.16,0.16,0.16,0.16],"rows":[["一般存储","通风、干燥、避光","8月","6月","","1.存储温度≤5℃<br>2.入库应掌握先进先出的原则，开封后需将包装封严，并尽快用完。"]],"title":["储存类型","储存要求","原料保质期","到货保质期","工厂保质期","存储说明"]}},{"type":"title","value":"八、对供应商的要求"},{"margins":5,"paddingfont":true,"type":"font","value":"1.每批进货供应商应随附自检报告；<br>2.检测项目依顶益公司规定的检验频率执行；<br>3.所有检测记录供应商应保存两年以上，以备顶益公司复审。"},{"type":"title","value":"九、参考标准"},{"margins":5,"paddingfont":true,"type":"font","value":"GB2762、GB2763、Q/LJL0014S、Q/LHL0002S、GB10146"},{"type":"title","value":"十、备注"},{"margins":5,"paddingfont":true,"type":"font","value":"1.原料等级：甲级。<br>2.该原料各项指标应满足康师傅规格及相关国家法规要求，同时需满足厂商执行标准。<br>3.其它瘦肉精(盐酸齐帕特罗ZilpaterolHydrochloride/盐酸多巴胺DopamineHydrochloride/苯乙醇胺APhenylethanolamineA/西布特罗Cimbuterol/班布特罗Bambuterol/酒石酸阿福特罗ArformoterolTartrate/富马酸福莫特罗FormoterolFumatrate/马贲特罗Mapenterol/苯氧丙酚胺Isoxsuprine/溴代克伦特罗Brom-chlorbuterol不得添加"}]`);


		preProcessData2(data_step1);
		preProcessData(data_step1, function(data_step2) {
			$('.loading1').shCircleLoader("destroy");
			appendPage(data_step2); //--数据源
			$("#pagination1").pagination({
				currentPage: 1, // 当前页数
				totalPage: nTotalPage - 1, // 总页数
				isShow: true, // 是否显示首尾页
				count: 7, // 显示个数
				homePageText: "首页", // 首页文本
				endPageText: "尾页", // 尾页文本
				prevPageText: "上一页", // 上一页文本
				nextPageText: "下一页", // 下一页文本
				callback: function(current) {

					showPages(current);
				}
			});
			finalProcess();
			
		});
	// })
	
	//html2pdf();
}

function processToLinkDLR()
{
	toPdf(true,function(){
		toLinkDLR();
	})
}

function toLinkDLR(){
	var specID = GetQueryString("specID");
	var specNum = staticdata.SpecNum;
	var specName = staticdata.SpecName; 
	var PDFName = staticdata.PDFName;
	window.open(encodeURI(encodeURI('http://11.24.201.170:8080/AutoSaveDRLDocument/index.html?specNum=' + specNum + '&specName=' + specName + '&specID=' + specID + "&pdfName=" + PDFName)));
	//window.open(encodeURI(encodeURI('http://11.24.201.15:8080/AutoSaveDRLDocument/index.html?number=' + number + '&specID=' + specID + "&specName=" + specName)));
}

function GetQueryString(specID) {  
    var reg = new RegExp("(^|&)" + specID + "=([^&]*)(&|$)");  
    var r = window.location.search.substr(1).match(reg);  
    if (r != null) {   
        return unescape(r[2]);  
    }  
    return null;  
} 

function reqData(fn_callback)
{
	var specID = GetQueryString("specID");
	$.ajax({
		type : "POST",
		url : "process/packingMatSlenderProcess.jsp?type=selectMaterial&specID=" + specID,
		dataType : "json",
		success : function(result) {
		 if (result.success) {
			staticdata.path = '';
			staticdata.EffectiveDate = result.EffectiveDate;
			staticdata.R3 = result.R3;
			staticdata.Version = result.Version;
			staticdata.DOCNO = result.DOCNO;
			staticdata.Level = result.Level;
			staticdata.zhiding = result.zhiding;
			staticdata.shenhe = result.shenhe;
			staticdata.pizhun = result.pizhun;
			staticdata.approve = result.approve;
			staticdata.SpecName = result.SpecName;
			staticdata.PDFName = result.PDFName;
			staticdata.SpecNum = result.SpecNum;
			/*staticdata.Attachment = result.Attachment;*/
			staticdata.qianhe = result.qianhe;
			if(staticdata.approve =="1"){
				staticdata.path = 'images_my/1.png';
			}else if(staticdata.approve =="2"){
				staticdata.path = 'images_my/2.png';
			}
			
			//var comUrl = 'file://119.119.115.47//plm4p_home//XDocuments//Drl//';
			
			var retData =result.recordsContainer;
				
			
			/*if(typeof(result.Attachment)!="undefined"){
				
				var imgArr =[];
				
				if(result.Attachment!="")
			    {
					var temp = result.Attachment.split('@$_$@');
					imgArr = temp.map(function(str){
	                    var obj = {};
						obj.msg =  str.split('@#_#@')[0];	
						obj.url =  str.split('@#_#@')[1];
						return obj;
					});
				}
				
				var _fujian = {
						type:"img",
						value:imgArr
				}
				
				retData.push(_fujian);
			}	*/	
 
			
			fn_callback(retData);
		}
		}
	});
}

function init()
{
	window.Dta = {
		containerWidth: cacuContainerWidth(), //--一页容器宽度
		containerHeight: cacuContainerHeight(), //--一页容器高度
		titleHeight: cacuTitleHeight(), //--标题高度
		linesize: cacuLineSize(), //--一行所占字节数
		tablelinesize:cacuTableCellLineHeight(),
		lineHeight:caculineHeight()
	}
	window.staticdata = {};
	window.nTotalPage = 1;//--加载完一共的页数
	window.nCurrent = 1;//--当前点击的页数
	window.fn_process_map = [];//--处理函数表
	
	window.fn_process_map["title"] = function(obj_container, onedata)
	{
		var $title = createTitle(onedata.value);
		if(onedata.callpages)
		{
			obj_container = CreateContainer();
		}
		if (obj_container.tryAdd(Dta.titleHeight)) {
			obj_container.add($title, Dta.titleHeight)
			return obj_container;
		} else {
			var obj_container_new = CreateContainer();
			return loop(obj_container_new, onedata)
		}
	}
	window.fn_process_map["font"] = function(obj_container, onedata)
	{
		
		var nMode = onedata.paddingfont ? 1 : !onedata.noparagraph ? -1 :0;
		
		var height = cacuFontHeight(onedata.value, nMode);
		
		if(onedata.margins)
			height+=onedata.margins*2;

		if (obj_container.tryAdd(height)) {
			
			var obj_text_container = new TextContainer(nMode, onedata.value, height);
			
			if(onedata.margins)
			{
				obj_text_container.setMarginTop(onedata.margins);
				obj_text_container.setMarginBottom(onedata.margins);
			}
			
			obj_container.add(obj_text_container.$dom, height);

			return obj_container;
		} else {
			
			var str_obj = {};
			if(obj_container.remainderHeight>Dta.lineHeight)	
			{
				var bIndent = nMode == -1;
	
				var pes = obj_container.remainderHeight / height;
				
				var remainedLength = GetLength(onedata.value);
										
				if(remainedLength < 2*Dta.linesize)
				{
					if(remainedLength<Dta.linesize)
						str_obj = {subed:"",remained:onedata.value};
					else{
						var firstChar = onedata.value.charAt(0);
						var second_cut_str = getbalanceStr(firstChar,splitstring(onedata.value,firstChar),nMode);
						
						str_obj = {
							subed: second_cut_str,
							remained: splitstring(onedata.value,second_cut_str)
						}
					}
				}
				else{
					
					str_obj = cutString(pes, onedata.value, nMode);
					
					if(GetLength(str_obj.subed) < Dta.linesize)
					{
						
						var second_cut_str = getbalanceStr(str_obj.subed, str_obj.remained, nMode);
	
						str_obj = {
							subed: second_cut_str,
							remained: splitstring(onedata.value,second_cut_str)
						}
													
					}
				}
					
				var height_append = cacuFontHeight(str_obj.subed, nMode);
				
				if(height_append)
				{
					if(onedata.margins)
					{
						height_append+=onedata.margins*2;
					}
					
					var obj_text_container_append = new TextContainer(nMode, str_obj.subed, height_append);
					
					if(onedata.margins)
					{
						obj_text_container_append.setMarginTop(onedata.margins);
						obj_text_container_append.setMarginBottom(onedata.margins);				
					}
					
					obj_container.add(obj_text_container_append.$dom, height_append);
				}
			}
			else
			{
				str_obj = {subed:"",remained:onedata.value};
			}
						
			var obj_container_new = CreateContainer();
			
			
			return loop(obj_container_new, {
				"type": "font",
				"value": str_obj.remained,
				"paddingfont":nMode==1,
				"margins":onedata.margins,
				"noparagraph": onedata.margins ? false : true //--表示这是截断段落。不需要间隔两格
			})

		}
		
	}
	window.fn_process_map["img"] = function(obj_container, onedata)
	{
		var curRetData = {index:0,container:null};

		while (curRetData.index != onedata.value.length) {

				var obj_img_container = new ImgContainer();

				var beforeIndex = curRetData.index;

				curRetData = appendImg(obj_img_container, onedata.value,curRetData.index);

				if (obj_container.tryAdd(curRetData.container.height)) {
				obj_container.add(curRetData.container.$dom,curRetData.container.height);
				}else{
				
				var obj_container_new = CreateContainer();
				
				var newDataArray = onedata.value.slice(beforeIndex);					
				return loop(obj_container_new,{"type":"img",value:newDataArray})
				}

		}
		return obj_container;
		
	}
	
	window.fn_process_map["table"] = function(obj_container, onedata) {

		var table = new Table({
			width: Dta.containerWidth - 96,
			marginleft:96/2,
			margintop:onedata.margintop ? onedata.margintop :0
		});

		if(onedata.margintop)//--若设置了margintop属性 则容器高度-10
			obj_container.remainderHeight = obj_container.remainderHeight-onedata.margintop;

		var pesAr =onedata.value.ratio ? onedata.value.ratio : onedata.rowsize ? onedata.rowsize : Table.prototype.caculatePes(onedata.value.rows);

		var bFirstRow = true;

		if (onedata.value.title) {
			bFirstRow = false;
			var titleRow = new tableRow({
				rowsize: pesAr,
				width: Dta.containerWidth - 96,
				bTop: true,
				data: onedata.value.title,
			})
			var addHeight = table.testAdd(titleRow);

			if (obj_container.tryAdd(addHeight)) {
				table.add(titleRow);
				bFirstRow = false;
			} else {
				var obj_container_new = CreateContainer();
				return loop(obj_container_new, {
					"type": "table",
					"margintop":10,
					"value": {
						"title": onedata.value.title,
						"rows": onedata.value.rows,
						"ratio":pesAr,
						
					}
				})
			}

		}

		for (var i = 0; i < onedata.value.rows.length; i++) {
			
			var _bBottom = i==onedata.value.rows.length-1;
			var _bTop = _bBottom ? false : bFirstRow&&i==0;
			var row = new tableRow({
				rowsize: pesAr,
				width: Dta.containerWidth - 96,
				bTop: _bTop,
				bBottom:_bBottom,
				data: onedata.value.rows[i],
			})

			var addHeight = table.testAdd(row);
			if (obj_container.tryAdd(addHeight)) {
				table.add(row);
			} else {
				table.endLine();
				obj_container.add(table.$dom, table.height);
				var obj_container_new = CreateContainer();

				var retainedRows = onedata.value.rows.slice(i);

				return loop(obj_container_new, {
					"type": "table",
					"margintop":10,//--下一页开头的表格距上边10个px
					"value": {
						"rows": retainedRows,
						"ratio":pesAr
					}
				})
			}
		}
		obj_container.add(table.$dom, table.height);
		return obj_container;
	}
	
}

function showPages(index) {
	$('.page').css('visibility', 'hidden');
	nCurrent = index;
	$('#page' + index).css('visibility', 'visible');
}

function finalProcess()
{
	$('.table_page').each(function(){
		
		$(this).text("页次："+ $(this).attr('pages')+"/"+(nTotalPage-1))
	})
}

function preProcessData(data, call_back) {

	var retData =data;
	var curCalbackEd = 0;
	var interval = 0;

	var nTotalCallback = data.filter(function(onedata) {
		return onedata.type == 'img';
	}).length;

	data.forEach(function(onedata, n) {
		if (onedata.type == 'img') {
			loadImg(n, onedata.value, function(imgarr, index) {
				retData[index].value = imgarr;
				curCalbackEd++;
			})
		}
	})

	interval = setInterval(function() {
		if (nTotalCallback == curCalbackEd) {
			clearInterval(interval);
			call_back(retData);
		}
	}, 10)
}

function preProcessData2(data)
{
	for(var i = 0 ; i < data.length ; i ++)
	{
		var onedata = data[i];
		if(onedata.type == 'font')
		{
			var valueList = onedata.value.split('<br>');
			
			var newFontList = valueList.map(function(sValue){
				
				return {
					"type":"font",
					"value":sValue,
					"margins":onedata.margins,
					"paddingfont":onedata.paddingfont,
				}
				//return $.extend(true,{},{"value":sValue})
			})
			
			var args = [];
			
			args[0] = i;
			args[1] = 1;
			args = args.concat(newFontList);
			Array.prototype.splice.apply(data,args);
			
			i = i - 1 + newFontList.length;
		}
	}
	
	
}

var loop = function(obj_container, onedata) {
	return window.fn_process_map[onedata.type](obj_container, onedata);
}

function appendPage(data) {

	var cur_container = CreateContainer();
	for (var i = 0; i < data.length; i++) {
		cur_container = loop(cur_container, data[i]);
	}
}

function appendImg(obj_img_container, ImgData,curIndex) {

	for (var i = curIndex; i < ImgData.length; i++) {
		var objImg = ImgData[i];
		if (obj_img_container.testAdd(objImg)) {
			obj_img_container.add(objImg);
		} else {
			return {
				container: obj_img_container,
				index: i
			}
		}
	}
	return {
		container: obj_img_container,
		index: ImgData.length
	}

}

function toPdf(is_java_do,fn_success) {
	var pdf = new jsPDF('', 'pt', 'a4');
	
	$('#imbed').css("visibility","visible");
	$('#imbed').css("zIndex",9999);
	$('#progressbar').LineProgressbar({
		percentage: 0,
		duration:0
	});

	for (var i = 1; i < nTotalPage; i++) {
		$('#page' + i).css('visibility', 'visible');
	}
	
	if(is_java_do)
	{
	
		var ret =[];
		
		html2pdf(1, pdf,ret);
		
		var interval1 = setInterval(function(){
			
			if(ret.length == nTotalPage-1)
			{
				clearInterval(interval1);
				postRequest(ret.map(function(d){
					
					return d.split(",")[1];
				}),fn_success);
			}
		},100)
	
	}else{
		html2pdf(1, pdf);
	}
	
	
	
	
}

function postRequest(ret,fn_success)
{
	var PDFName = staticdata.PDFName;
	var post = {
		image:ret
	}
	$.ajax({
		url : "process/packingMatSlenderProcess.jsp?type=createpdf&pdfName=" + encodeURI(PDFName),
		type:'post',
		data:post,
		success:function(){
			if(fn_success && typeof fn_success == 'function')
				fn_success();
			
		}
	})
}

function returnToBefore()
{
	$('#progressbar').LineProgressbar({
		percentage: 100,
		duration:0
	});
	
	$('#imbed').css('visibility','hidden');
	showPages(nCurrent);
	
}

function html2pdf(index, pdf,ret) {
	
	setTimeout(function(){
		$('#progressbar').LineProgressbar({
			percentage: parseInt(100* ((index-1)/(nTotalPage-1))),
			duration:0
		});
	},5)
	
	var shareContent = document.getElementById("page" + index);//需要截图的包裹的（原生的）DOM 对象
	var width = shareContent.offsetWidth; //获取dom 宽度
	var height = shareContent.offsetHeight; //获取dom 高度
	var canvas = document.createElement("canvas"); //创建一个canvas节点
	var scale = 1.5; //定义任意放大倍数 支持小数
	canvas.width = width * scale; //定义canvas 宽度 * 缩放
	canvas.height = height * scale; //定义canvas高度 *缩放
	canvas.getContext("2d").scale(scale, scale); //获取context,设置scale 
	var opts = {
		scale: scale, // 添加的scale 参数
		canvas: canvas, //自定义 canvas
		logging: true, //日志开关
		width: width, //dom 原始宽度
		height: height //dom 原始高度
	};


	html2canvas(shareContent, opts).then(function (canvas) {
		    var contentWidth = 770;
			var contentHeight = 1096;
			//一页pdf显示html页面生成的canvas高度;
			var pageHeight = contentWidth / 592.28 * 841.89;
			//未生成pdf的html页面高度
			var leftHeight = contentHeight;
			//pdf页面偏移
			var position = 0;
			//a4纸的尺寸[595.28,841.89]，html页面生成的canvas在pdf中图片的宽高
			var imgWidth = 595.28;
			var imgHeight = 592.28 / contentWidth * contentHeight;

			var pageData = canvas.toDataURL();
			
			if(ret && $.isArray(ret))
			{
				ret.push(pageData)
			}
			else
			{
				pdf.addImage(pageData, 'png', 0, 0, 592.28, 841.89);
			}

			 //$('#testimg').get(0).src = pageData;

//			

			if (index != nTotalPage-1) {
				
				if(!ret)
					pdf.addPage();
				//if()
				html2pdf(++index, pdf,ret);
			} else {
				returnToBefore();
				if(!ret)
					pdf.save(staticdata.PDFName+'.pdf');
				//var blob = pdf.output('blob');
				
			}
	});

}


function CreateContainer()
{
	var $newContainer = createPages(staticdata.SpecName,staticdata.EffectiveDate,staticdata.R3,staticdata.Version,staticdata.DOCNO,staticdata.Level,staticdata.zhiding,staticdata.shenhe,staticdata.pizhun,staticdata.path,staticdata.qianhe);
	return new Container($newContainer);
}