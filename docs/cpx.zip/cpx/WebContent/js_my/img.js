﻿
function loadImg(index, imgdata, callback) {
    var retArr = [];
    var interval = 0;

    imgdata.forEach(function(imgdata) {
        var obj_img = new Img({
            msg: imgdata.msg,
            url: imgdata.url,
            maxWidth:Dta.containerWidth-15,//--imageContainer maringleft+marginright
            maxHight:Dta.containerHeight,
            onLoad: function() {
                retArr.push(this);
            }
        });
    });

    interval = setInterval(function() {
        if (imgdata.length == retArr.length) {
            clearInterval(interval);
            callback(retArr, index);
        }
    }, 10)
}