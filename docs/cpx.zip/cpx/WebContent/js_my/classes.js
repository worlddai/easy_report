﻿//--主容器类
function Container($page) {
	this.$dom = $page;
	this.remainderHeight = Dta.containerHeight;
	this.tryAdd = function(nHeight) {
		return this.remainderHeight > nHeight;
	}
	this.add = function(ele, nHeight) {
		this.$dom.append(ele);
		this.remainderHeight = this.remainderHeight - nHeight;
	}
}
//--文字容器类
function TextContainer(nMode, sText, height) {
	
	this.createClass = nMode == -1 ? "indent" : nMode == 0 ? "" :"text-padding";
	
	this.marginTop = 0;

	this.createTextContainer = function(nMode, sText) {
		return $('<div style = "margin-top:'+this.marginTop+';" class = "text-container ' + this.createClass + '">' + sText + '</div>');
	}
	this.$dom = this.createTextContainer(nMode, sText);
	this._nHeight = height;
	
	this.setMarginTop = function(margin)
	{
		this.$dom.css("margin-top",margin);
		
	}
	this.setMarginBottom = function(margin)
	{
		this.$dom.css("margin-bottom",margin);
		
	}
	
}
//--img类
function Img(opt) {
    var defaults = {
            url: "",
            msg: "图1",
            tipsHeight: 20,
            maxWidth:700,
            maxHight:700,
            onLoad: function() {}
        },
        opts = {},
        parseOptions = function() {
            $.extend(opts, defaults, opt);
        },
        self = this;
    parseOptions();
    this._bLoaded = false;
    this.$dom = $('<div class = "img_parent"></div>');
    this.$img = $('<img class = "_img" style = "visibility:hidden">').appendTo('body');
    this._width = 0;
    this._height = 0;
    
    
    this.DrawImage = function(ImgD){      
        //参数(图片,允许的宽度,允许的高度)          
    	  	var image=new Image();  
    	  	var iwidth = opts.maxWidth;
    	  	var iheight = opts.maxHight;
		    image.src=ImgD.src;      
		    if(image.width>0 && image.height>0){      
		      if(image.width/image.height>= iwidth/iheight){      
		          if(image.width>iwidth){        
		              ImgD.width=iwidth;      
		              ImgD.height=(image.height*iwidth)/image.width;      
		          }else{      
		              ImgD.width=image.width;        
		              ImgD.height=image.height;      
		          }      
		      }else{      
		          if(image.height>iheight){        
		              ImgD.height=iheight;      
		              ImgD.width=(image.width*iheight)/image.height;              
		          }else{      
		              ImgD.width=image.width;        
		              ImgD.height=image.height;      
		          }      
		      }      
		    }     
    }

    $.ajax({
		type : "POST",
		url : "process/packingMatSlenderProcess.jsp?type=path&url="+opts.url,
		dataType : "json",
		success : function(result) {
			
			var base64 = result.base64;
			
			self.$img.get(0).src = base64;
			
			setTimeout(function()
				{
					
				    var nImgHeight = self.$img.height();
			        var nImgWidth = self.$img.width();
			        if(nImgHeight>opts.maxHeight||nImgWidth>opts.maxWidth)
			        {
			        	
			        	self.DrawImage(self.$img.get(0));
			        }
			        	
			        
			        nImgHeight = self.$img.height();
			        nImgWidth = self.$img.width();
			        
			        self._width = nImgWidth;
			        self._height = nImgHeight + opts.tipsHeight;
			       

			        self.$dom.width(nImgWidth);
			        self.$img.css('visibility', 'inherit');
			        self.$dom.append(self.$img);
			        self.$dom.append($('<div style = "width:' + nImgWidth + 'px;height:' + opts.tipsHeight + 'px" class = "img-tips">' + opts.msg + '</div>'));
			        opts.onLoad.call(self);
			
				},80)
	    	
	      
		}
	});
    
    //opts.fn_ajax(opts.url,this.onload);
    //this.onload();
}

//--img容器类
function ImgContainer() {

    var defaults = {
        margin_left: 10,
        margin_right: 5,
        img_splice: 20,
        margin_top:5,
        margin_bottom:5
    },self = this;
    this.$dom = $('<div style = "padding-top:'+defaults.margin_top+'px;padding-bottom:'+defaults.margin_bottom+'px" class = "img-container"><div class = "content-clear"></div></div>')
    this.retainedWidth = Dta.containerWidth;
    this.height = 0;
    this.curBegin = defaults.margin_left;
    this.arr_img = [];
    
   
    
    this.testAdd = function(img) {

        if(!this.arr_img.length)//--第一张直接放
            return true;
        else{
            return this.retainedWidth > (img._width + defaults.img_splice+defaults.margin_left);
        }
    
    }
    this.add = function(img) {

        img.$dom.insertBefore(this.$dom.find("div.content-clear"));

        if(!this.arr_img.length)//--第一个图距左边的距离
            img.$dom.css('left', defaults.margin_left);
        else
            img.$dom.css('left', defaults.img_splice+defaults.margin_left);//--每个图间隔
        this.retainedWidth = this.retainedWidth-img._width;
        this.arr_img.push(img);
        this.height = Math.max.apply({}, this.arr_img.map(function(img) {
            return img._height;
        }))+defaults.margin_top+defaults.margin_bottom
    }

}


