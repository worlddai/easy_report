﻿function tableRow(opt) {
	var defaults = {
		rowsize: [0.5, 0.5],
		data: ["aaaaaaa", "bbbbbbbbbb"],
		width: 700,
		bTop: false,
		bBottom: false,
		bTitle: false,
		disableLine: false
	},
		opts = {},
		parseOptions = function () {
			$.extend(opts, defaults, opt);
		},
		_append = function (str, index, arr,row_size,maxHeight) {
			var str_class_ext = opts.disableLine ? "table-cell-noborder" : index == 0 ? "cell-left" : index == (arr.length - 1) ? "cell-right" : "";

			var bMutypleLine = cacuTableLines(str, (opts.width * row_size)) > 1;

			$('<div class = "table-cell ' + str_class_ext + '" style = "' + (bMutypleLine ? 'padding-top:2px;padding-bottom:2px;' : '') + 'width:' + (row_size * 100) + '%;height:' + maxHeight + 'px;' + (bMutypleLine ? '' : 'line-height:' + maxHeight + 'px;') + '">' + str + '</div>').insertBefore(self.$dom.find('#row-content-clear'));

		},
		init = function () {



			var maxHeight;
			// var self = this;

			//--2020-05-11  说明栏 合并2列
			if (opts.data[0] == "说明") {
				maxHeight = Math.max.apply({}, [
					cacuTableCellHeight(opts.data[1], (Number(opts.rowsize[1]) + Number(opts.rowsize[2])) * opts.width),
					cacuTableCellHeight(opts.data[3], opts.rowsize[3] * opts.width),
				]) + 4;


				var str, index, arr;

				str = "说明";
				index = 0;
				arr = [
					opts.data[0],
					opts.data[1],
					opts.data[3]
				];

				_append(str,index, arr,opts.rowsize[index],maxHeight);


				index = 1;
				str = opts.data[1];

				_append(str,index, arr,Number(opts.rowsize[1])+Number(opts.rowsize[2]),maxHeight);

				index = 2;
				str = opts.data[3];

				_append(str,index, arr,opts.rowsize[3],maxHeight);


				self.height = maxHeight + (opts.disableLine ? 0 : opts.bTitle ? 10 : (opts.bTop || opts.bBottom) ? 1 : 2) //--边框高度计算在内
			}
			else {
				maxHeight = Math.max.apply({}, opts.data.map(function (str, i) {
					return cacuTableCellHeight(str, opts.rowsize[i] * opts.width);
				})) + 4;

				opts.data.forEach(function (str, index, arr) {

					_append(str,index, arr,opts.rowsize[index],maxHeight);
				})
	
				self.height = maxHeight + (opts.disableLine ? 0 : opts.bTitle ? 10 : (opts.bTop || opts.bBottom) ? 1 : 2) //--边框高度计算在内
			}
		},
		self = this;
	parseOptions();
	this.height = 0;

	this.setEnd = function () {
		this.$dom.addClass('row-bottom');
	}

	this.$dom = $('<div style = "width:' + opts.width + 'px;" class = "table-row ' + (opts.bTitle ? "row-title" : opts.disableLine ? "table-row-noborder" : opts.bTop ? "row-top" : opts.bBottom ? "row-bottom" : "") + '"><div id = "row-content-clear" class = "content-clear"></div></div>');

	init();

}

function Table(opt) {
	var defaults = {
		width: 720,
		marginleft: 5,
		margintop: 0
	},
		opts = {},
		parseOptions = function () {
			$.extend(opts, defaults, opt);
		},
		init = function () {

		},
		self = this;
	parseOptions();

	this.height = 0;

	this._rowList = [];

	this.$dom = $('<div class = "table_container" style = "margin-top:' + opts.margintop + 'px;margin-left:' + opts.marginleft + 'px;width:' + opts.width + 'px"><div id = "table-content-clear" class = "content-clear"></div></div>');

	this.testAdd = function (tablerow) {
		return this.height + tablerow.height;
	}

	this.add = function (tablerow) {
		tablerow.$dom.insertBefore(this.$dom.find('#table-content-clear'));
		this._rowList.push(tablerow);
		this.height = this.height + tablerow.height;
	}
	this.endLine = function () {
		if (this._rowList.length)
			this._rowList[this._rowList.length - 1].setEnd();
	}


}
Table.prototype.caculatePes = function (datalist) {
	var nTotalCell = datalist[0].length;

	var totalArr = [];

	for (var j = 0; j < nTotalCell; j++) {
		for (var i = 0; i < datalist.length; i++) {
			totalArr[j] = totalArr[j] + datalist[i][j];
		}
	}
	var totalStrlength = GetLength(totalArr.join(""));
	return totalArr.map(function (str) {
		return GetLength(str) / totalStrlength;
	})
}