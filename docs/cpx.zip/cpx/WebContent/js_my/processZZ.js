﻿window.onload = function() {
	//--初始化相关参数及函数
	init();

	//--预处理图片相关数据
	$('.loading1').shCircleLoader();
	reqData(function(data_step1){
		preProcessData2(data_step1);
		preProcessData(data_step1, function(data_step2) {
			$('.loading1').shCircleLoader("destroy");
			appendPage(data_step2); //--数据源
			$("#pagination1").pagination({
				currentPage: 1, // 当前页数
				totalPage: nTotalPage - 1, // 总页数
				isShow: true, // 是否显示首尾页
				count: 7, // 显示个数
				homePageText: "首页", // 首页文本
				endPageText: "尾页", // 尾页文本
				prevPageText: "上一页", // 上一页文本
				nextPageText: "下一页", // 下一页文本
				callback: function(current) {

					showPages(current);
				}
			});
			finalProcess();
			
		});
	})
	
	//html2pdf();
}

function processToLinkDLR()
{
	toPdf(true,function(){
		toLinkDLR();
	})
}


function toLinkDLR(){
	var specID = GetQueryString("specID");
	var specNum = staticdata.SpecNum;
	var specName = staticdata.SpecName; 
	var PDFName = staticdata.PDFName;
	window.open(encodeURI(encodeURI('http://11.24.201.170:8080/AutoSaveDRLDocument/index.html?specNum=' + specNum + '&specName=' + specName + '&specID=' + specID + "&pdfName=" + PDFName)));
}

function GetQueryString(specID) {  
    var reg = new RegExp("(^|&)" + specID + "=([^&]*)(&|$)");  
    var r = window.location.search.substr(1).match(reg);  
    if (r != null) {   
        return unescape(r[2]);  
    }  
    return null;  
} 

function reqData(fn_callback)
{
	var specID = GetQueryString("specID");
	$.ajax({
		type : "POST",
		url : "process/packingMatSlenderProcess.jsp?type=queryZZ&specID=" + specID,
		dataType : "json",
		success : function(result2) {
			var result = result2;
			staticdata.path = '';
			staticdata.EffectiveDate = result.EffectiveDate;
			staticdata.R3 = result.R3;
			staticdata.Version = result.Version;
			staticdata.DOCNO = result.DOCNO;
			staticdata.Level = result.Level;
			staticdata.zhiding = result.zhiding;
			staticdata.shenhe1 = result.shenhe1;
			staticdata.shenhe2 = result.shenhe2;
			staticdata.pizhun = result.pizhun;
			staticdata.approve = result.approve;
			staticdata.Attachment = result.Attachment;
			staticdata.SpecName = result.SpecName;
			staticdata.PDFName = result.PDFName;
			staticdata.SpecNum = result.SpecNum;
			if(staticdata.approve =="1"){
				staticdata.path = 'images_my/1.png';
			}else if(staticdata.approve =="2"){
				staticdata.path = 'images_my/2.png';
			}
			
			//var comUrl = 'file://119.119.115.47//plm4p_home//XDocuments//Drl//';
			var retData =result.recordsContainer;
			
			retData.forEach(function(obj,i){
				
				if(obj.type == "img")
				{
					var imgArr =[];
					
					if(obj.value!="")
				    {
						var temp = obj.value.split('@$_$@');
						imgArr = temp.map(function(str){
		                    var obj = {};
							obj.msg =  str.split('@#_#@')[0];	
							obj.url =  str.split('@#_#@')[1];
							return obj;
						});
					}
					retData[i].value = imgArr;
				}
			})
			
			
//			if(typeof(result.Attachment)!="undefined"){
//				
//				var imgArr =[];
//				
//				if(result.Attachment!="")
//			    {
//					var temp = result.Attachment.split('@$_$@');
//					imgArr = temp.map(function(str){
//	                    var obj = {};
//						obj.msg =  str.split('@#_#@')[0];	
//						obj.url =  str.split('@#_#@')[1];
//						return obj;
//					});
//				}
//				retData[11].value = imgArr;
//			}		
 
			
			fn_callback(retData);
		}
	});
}

function init()
{
	window.Dta = {
		containerWidth: cacuContainerWidth(), //--一页容器宽度
		containerHeight: cacuContainerHeight(), //--一页容器高度
		titleHeight: cacuTitleHeight(), //--标题高度
		linesize: cacuLineSize() //--一行所占字节数
	}
	window.staticdata = {};
	window.nTotalPage = 1;//--加载完一共的页数
	window.nCurrent = 1;//--当前点击的页数
	window.fn_process_map = [];//--处理函数表
	
	window.fn_process_map["title"] = function(obj_container, onedata)
	{
		var $title = createTitle(onedata.value);
		if(onedata.callpages)
		{
			obj_container = CreateContainer();
		}
		if (obj_container.tryAdd(Dta.titleHeight)) {
			obj_container.add($title, Dta.titleHeight)
			return obj_container;
		} else {
			var obj_container_new = CreateContainer();
			return loop(obj_container_new, onedata)
		}
	}
	window.fn_process_map["font"] = function(obj_container, onedata)
	{
		var nMode = onedata.paddingfont ? 1 : !onedata.noparagraph ? -1 :0;
		
		var height = cacuFontHeight(onedata.value, nMode);

		if (obj_container.tryAdd(height)) {
			
			var obj_text_container = new TextContainer(nMode, onedata.value, height);
						
			
			obj_container.add(obj_text_container.$dom, height);

			return obj_container;
		} else {
			var bIndent = nMode == -1;

			var pes = obj_container.remainderHeight / height;
			
			var remainedLength = GetLength(onedata.value);
			
			var str_obj = {};
			
			if(remainedLength < 2*Dta.linesize)
			{
				str_obj = {subed:"",remained:onedata.value};
			}
			else{
				
				str_obj = cutString(pes, onedata.value, nMode);
				
				if(GetLength(str_obj.subed) < Dta.linesize)
				{
					
					var second_cut_str = getbalanceStr(str_obj.subed, str_obj.remained, nMode);

					str_obj = {
						subed: second_cut_str,
						remained: splitstring(onedata.value,second_cut_str)
					}
												
				}
			}
				
			var height_append = cacuFontHeight(str_obj.subed, nMode);

			var obj_text_container_append = new TextContainer(nMode, str_obj.subed, height_append);

			obj_container.add(obj_text_container_append.$dom, height_append);

			var obj_container_new = CreateContainer();

			return loop(obj_container_new, {
				"type": "font",
				"value": str_obj.remained,
				"paddingfont":nMode==1,
				"noparagraph": true //--表示这是截断段落。不需要间隔两格
			})

		}
	}
	window.fn_process_map["img"] = function(obj_container, onedata)
	{
		var curRetData = {index:0,container:null};

		while (curRetData.index != onedata.value.length) {

				var obj_img_container = new ImgContainer();

				var beforeIndex = curRetData.index;

				curRetData = appendImg(obj_img_container, onedata.value,curRetData.index);

				if (obj_container.tryAdd(curRetData.container.height)) {
				obj_container.add(curRetData.container.$dom,curRetData.container.height);
				}else{
				
				var obj_container_new = CreateContainer();
				
				var newDataArray = onedata.value.slice(beforeIndex);					
				return loop(obj_container_new,{"type":"img",value:newDataArray})
				}

		}
		return obj_container;
		
	}
	
	window.fn_process_map["table"] = function(obj_container, onedata) {

		var table = new Table({
			width: Dta.containerWidth - 20,
			marginleft:20/2,
			margintop:onedata.margintop ? onedata.margintop :0
		});

		if(onedata.margintop)//--若设置了margintop属性 则容器高度-10
			obj_container.remainderHeight = obj_container.remainderHeight-onedata.margintop;

		var pesAr = onedata.rowsize ? onedata.rowsize : Table.prototype.caculatePes(onedata.value.rows);

		var bFirstRow = true;

		if (onedata.value.title) {
			bFirstRow = false;
			var titleRow = new tableRow({
				rowsize: pesAr,
				width: Dta.containerWidth - 20,
				bTop: true,
				data: onedata.value.title,
			})
			var addHeight = table.testAdd(titleRow);

			if (obj_container.tryAdd(addHeight)) {
				table.add(titleRow);
				bFirstRow = false;
			} else {
				var obj_container_new = CreateContainer();
				return loop(obj_container_new, {
					"type": "table",
					"value": {
						"title": onedata.value.title,
						"rows": onedata.value.rows
					}
				})
			}

		}

		for (var i = 0; i < onedata.value.rows.length; i++) {
			var row = new tableRow({
				rowsize: pesAr,
				width: Dta.containerWidth - 20,
				bTop: bFirstRow&&i==0,
				bBottom:i==onedata.value.rows.length-1,
				data: onedata.value.rows[i],
			})

			var addHeight = table.testAdd(row);

			if (obj_container.tryAdd(addHeight)) {
				table.add(row);
			} else {
				table.endLine();
				obj_container.add(table.$dom, table.height);
				var obj_container_new = CreateContainer();

				var retainedRows = onedata.value.rows.slice(i);

				return loop(obj_container_new, {
					"type": "table",
					"margintop":10,//--下一页开头的表格距上边10个px
					"value": {
						"rows": retainedRows
					}
				})
			}
		}
		obj_container.add(table.$dom, table.height);
		return obj_container;
	}
	
}

function showPages(index) {
	$('.page').css('visibility', 'hidden');
	nCurrent = index;
	$('#page' + index).css('visibility', 'visible');
}

function finalProcess()
{
	$('.table_page').each(function(){
		
		$(this).text("页次："+ $(this).attr('pages')+"/"+(nTotalPage-1))
	})
}

function preProcessData2(data)
{
	for(var i = 0 ; i < data.length ; i ++)
	{
		var onedata = data[i];
		if(onedata.type == 'font')
		{
			var valueList = onedata.value.split('<br>');
			
			var newFontList = valueList.map(function(sValue){
				
				return {
					"type":"font",
					"value":sValue,
					"paddingfont":onedata.paddingfont,
				}
			})
			
			var args = [];
			
			args[0] = i;
			args[1] = 1;
			args = args.concat(newFontList);
			Array.prototype.splice.apply(data,args);
			
			i = i - 1 + newFontList.length;
		}
	}
	
	
}

function preProcessData(data, call_back) {

	var retData =data;
	var curCalbackEd = 0;
	var interval = 0;

	var nTotalCallback = data.filter(function(onedata) {
		return onedata.type == 'img';
	}).length;

	data.forEach(function(onedata, n) {
		if (onedata.type == 'img') {
			loadImg(n, onedata.value, function(imgarr, index) {
				retData[index].value = imgarr;
				curCalbackEd++;
			})
		}
	})

	interval = setInterval(function() {
		if (nTotalCallback == curCalbackEd) {
			clearInterval(interval);
			call_back(retData);
		}
	}, 10)
}

var loop = function(obj_container, onedata) {
	return window.fn_process_map[onedata.type](obj_container, onedata);
}

function appendPage(data) {

	var cur_container = CreateContainer();
	for (var i = 0; i < data.length; i++) {
		cur_container = loop(cur_container, data[i]);
	}
}

function appendImg(obj_img_container, ImgData,curIndex) {

	for (var i = curIndex; i < ImgData.length; i++) {
		var objImg = ImgData[i];
		if (obj_img_container.testAdd(objImg)) {
			obj_img_container.add(objImg);
		} else {
			return {
				container: obj_img_container,
				index: i
			}
		}
	}
	return {
		container: obj_img_container,
		index: ImgData.length
	}

}

function toPdf(is_java_do,fn_success) {
	var pdf = new jsPDF('', 'pt', 'a4');
	
	$('#imbed').css("visibility","visible");
	$('#imbed').css("zIndex",9999);
	$('#progressbar').LineProgressbar({
		percentage: 0,
		duration:0
	});

	for (var i = 1; i < nTotalPage; i++) {
		$('#page' + i).css('visibility', 'visible');
	}
	
	if(is_java_do)
	{
	
		var ret =[];
		
		html2pdf(1, pdf,ret);
		
		var interval1 = setInterval(function(){
			
			if(ret.length == nTotalPage-1)
			{
				clearInterval(interval1);
				postRequest(ret.map(function(d){
					
					return d.split(",")[1];
				}),fn_success);
			}
		},100)
	
	}else{
		html2pdf(1, pdf);
	}
	
	
	
	
}

function postRequest(ret,fn_success)
{
	var PDFName = staticdata.PDFName;
	var post = {
		image:ret
	}
	$.ajax({
		url :  "process/packingMatSlenderProcess.jsp?type=createpdf&pdfName=" + encodeURI(PDFName),
		type:'post',
	
		data:post,
		success:function(){
			if(fn_success && typeof fn_success == 'function')
				fn_success();
			
		}
	})
}

function returnToBefore()
{
	$('#progressbar').LineProgressbar({
		percentage: 100,
		duration:0
	});
	
	$('#imbed').css('visibility','hidden');
	showPages(nCurrent);
	
}


function html2pdf(index, pdf,ret) {
	
	setTimeout(function(){
		$('#progressbar').LineProgressbar({
			percentage: parseInt(100* ((index-1)/(nTotalPage-1))),
			duration:0
		});
	},5)
	
	var shareContent = document.getElementById("page" + index);//需要截图的包裹的（原生的）DOM 对象
	var width = shareContent.offsetWidth; //获取dom 宽度
	var height = shareContent.offsetHeight; //获取dom 高度
	var canvas = document.createElement("canvas"); //创建一个canvas节点
	var scale = 1.5; //定义任意放大倍数 支持小数
	canvas.width = width * scale; //定义canvas 宽度 * 缩放
	canvas.height = height * scale; //定义canvas高度 *缩放
	canvas.getContext("2d").scale(scale, scale); //获取context,设置scale 
	var opts = {
		scale: scale, // 添加的scale 参数
		canvas: canvas, //自定义 canvas
		logging: true, //日志开关
		width: width, //dom 原始宽度
		height: height //dom 原始高度
	};


	html2canvas(shareContent, opts).then(function (canvas) {
		    var contentWidth = 770;
			var contentHeight = 1096;
			//一页pdf显示html页面生成的canvas高度;
			var pageHeight = contentWidth / 592.28 * 841.89;
			//未生成pdf的html页面高度
			var leftHeight = contentHeight;
			//pdf页面偏移
			var position = 0;
			//a4纸的尺寸[595.28,841.89]，html页面生成的canvas在pdf中图片的宽高
			var imgWidth = 595.28;
			var imgHeight = 592.28 / contentWidth * contentHeight;
			
			var pageData = canvas.toDataURL();
			
			if(ret && $.isArray(ret))
			{
				ret.push(pageData)
			}
			else
			{
				pdf.addImage(pageData, 'png', 0, 0, 592.28, 841.89);
			}

			if (index != nTotalPage-1) {
				
				if(!ret)
					pdf.addPage();
				//if()
				html2pdf(++index, pdf,ret);
			} else {
				returnToBefore();
				if(!ret)
					pdf.save(staticdata.PDFName+'.pdf');
				//var blob = pdf.output('blob');
				
			}
	});

}

function toSlenderLink(){
	
}

function CreateContainer()
{
	var $newContainer = createPages(staticdata.SpecName,staticdata.EffectiveDate,staticdata.R3,staticdata.Version,staticdata.DOCNO,staticdata.Level,staticdata.zhiding,staticdata.shenhe1,staticdata.shenhe2,staticdata.pizhun,staticdata.path);
	return new Container($newContainer);
}